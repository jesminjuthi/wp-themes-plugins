<?php
/**
 * Popup trigger
 */
?>
<div class="jet-search__popup-trigger-container">
	<button type="button" class="jet-search__popup-trigger"><?php
		$this->__icon( 'search_popup_trigger_icon', '<span class="jet-search__popup-trigger-icon jet-blocks-icon">%s</span>' )
	?></button>
</div>