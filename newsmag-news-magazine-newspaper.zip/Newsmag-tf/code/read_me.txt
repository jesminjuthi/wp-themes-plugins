[Newsmag-child]
 - is the sample child theme 
 - documentation: http://forum.tagdiv.com/the-child-theme-support-tutorial/
 

[td-api-plugin]
 - is a sample plugin that uses the theme api to add a new module, a new block. This plugin is a very good starting point if you wish to add your own modules or just modify a block / module from the theme.
 - the new module can be used on loops
 - the new block appears in visual composer
 - the theme api documentation is here: http://forum.tagdiv.com/the-theme-api/